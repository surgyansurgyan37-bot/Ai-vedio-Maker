import os, uuid
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

app = FastAPI(title='AI Video Maker')

@app.get('/', response_class=HTMLResponse)
async def home():
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'public', 'index.html')
    with open(path, 'r', encoding='utf-8') as f:
        return HTMLResponse(f.read())

@app.post('/api/create')
async def create(request: Request):
    data = await request.json()
    script = (data.get('script') or '').strip()
    duration = data.get('duration', 60)
    style = data.get('style', 'Cinematic')
    ratio = data.get('ratio', '16:9')
    if not script:
        return JSONResponse({'ok': False, 'error': 'Script खाली है.'}, status_code=400)
    sentences = [x.strip() for x in script.replace('\n', ' ').split('.') if x.strip()] or [script]
    scenes = []
    for i, sentence in enumerate(sentences[:12], 1):
        scenes.append({'scene': i, 'text': sentence, 'visual_prompt': f'{style}, realistic cinematic shot, {sentence}', 'duration_seconds': max(3, int(duration / max(1, min(len(sentences), 12))))})
    return {'ok': True, 'project_id': str(uuid.uuid4()), 'duration': duration, 'style': style, 'ratio': ratio, 'scenes': scenes, 'message': 'Scene plan तैयार है.'}

@app.get('/api/health')
async def health():
    return {'ok': True, 'service': 'AI Video Maker'}
