# AI Video Maker — Live Backend MVP

1. Node.js install करें.
2. `npm install`
3. अपने server में `OPENAI_API_KEY` environment variable सेट करें.
4. `npm start`
5. Browser में `http://localhost:3000` खोलें.

API key को frontend HTML में न रखें.
यह version real Script और Voice API endpoints देता है.
Scene image/video generation और final MP4 rendering अभी अलग backend service के रूप में जोड़ना बाकी है.
