import express from "express";
import cors from "cors";
import multer from "multer";
import OpenAI from "openai";
import fs from "fs";

const app = express();
const upload = multer({dest:"uploads/"});
app.use(cors());
app.use(express.json({limit:"3mb"}));
app.use(express.static("public"));

const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({apiKey}) : null;

app.get("/api/health",(req,res)=>res.json({ok:true, apiConnected:!!client}));

app.post("/api/script", async (req,res)=>{
  try {
    if(!client) return res.status(503).json({error:"OPENAI_API_KEY server पर सेट नहीं है।"});
    const {topic, language="Hindi", duration="5 मिनट"}=req.body;
    if(!topic) return res.status(400).json({error:"Topic जरूरी है।"});
    const r=await client.responses.create({
      model:"gpt-5.6-luna",
      input:`Write a YouTube video script in ${language} about "${topic}" for approximately ${duration}. Include a strong hook, introduction, scene-by-scene narration, useful information and an ending. Plain text only.`
    });
    res.json({script:r.output_text});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/voice",async(req,res)=>{
  try {
    if(!client) return res.status(503).json({error:"OPENAI_API_KEY server पर सेट नहीं है।"});
    const {text}=req.body;
    if(!text) return res.status(400).json({error:"Script text जरूरी है।"});
    const speech=await client.audio.speech.create({
      model:"gpt-4o-mini-tts", voice:"alloy", input:text, response_format:"mp3"
    });
    const file=`uploads/voice-${Date.now()}.mp3`;
    fs.mkdirSync("uploads",{recursive:true});
    fs.writeFileSync(file,Buffer.from(await speech.arrayBuffer()));
    res.json({file:"/"+file});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/upload",upload.single("photo"),(req,res)=>{
  if(!req.file)return res.status(400).json({error:"Photo नहीं मिली।"});
  res.json({file:"/"+req.file.path});
});

app.listen(process.env.PORT||3000,()=>console.log("AI Video Maker running"));
